// --- Product Data Catalog ---
const PRODUCTS = [
  {
    id: 'rolex-daytona',
    name: 'Rolex Cosmograph Daytona',
    category: 'rolex',
    categoryName: 'Rolex',
    price: 48500,
    priceStr: '48.500 $',
    imageKey: 'rolex_daytona',
    badge: 'İkonik',
    shortDesc: '18 Karat Sarı Altın ve Oysterflex kordon ile zamansız bir başyapıt.',
    description: 'Rolex Cosmograph Daytona, yarış pistleri için tasarlanmış ve zamanla lüks saat dünyasının en büyük simgelerinden biri haline gelmiştir. 18 karat sarı altın kasa, siyah cerachrom seramik çerçeve ve patentli Oysterflex elastomer kordon ile spor şıklığı ve eşsiz zarafeti bir arada sunar.',
    specs: {
      'Referans': '116518LN',
      'Kasa Çapı': '40 mm',
      'Materyal': '18k Sarı Altın',
      'Kadran': 'Altın ve Siyah',
      'Mekanizma': 'Otomatik, Kalibre 4130',
      'Güç Rezervi': '72 Saat'
    }
  },
  {
    id: 'patek-nautilus',
    name: 'Patek Philippe Nautilus 5711',
    category: 'patek',
    categoryName: 'Patek Philippe',
    price: 115000,
    priceStr: '115.000 $',
    imageKey: 'patek_nautilus',
    badge: 'Nadir',
    shortDesc: 'Paslanmaz çelik kasa ve büyüleyici mavi kadranı ile lüks spor saatin zirvesi.',
    description: 'Gérald Genta tarafından tasarlanan efsanevi Nautilus kasası, yat pencerelerinden ilham alan sekizgen bezeli ile tanınır. Yatay kabartmalı mavi kadranı, çelik bileziği ve mükemmel işçiliğiyle saat koleksiyonerlerinin en çok arzuladığı modellerin başında yer alır.',
    specs: {
      'Referans': '5711/1A-010',
      'Kasa Çapı': '40 mm',
      'Materyal': 'Paslanmaz Çelik',
      'Kadran': 'Mavi',
      'Mekanizma': 'Otomatik, Kalibre 26-330 S C',
      'Güç Rezervi': '45 Saat'
    }
  },
  {
    id: 'diamond-earrings',
    name: 'Lüks Pırlanta Damla Küpe',
    category: 'kupe',
    categoryName: 'Küpe',
    price: 24800,
    priceStr: '24.800 $',
    imageKey: 'diamond_earrings',
    badge: 'Özel Seri',
    shortDesc: 'Göz alıcı 18 ayar beyaz altın üzeri damla kesim elmas küpeler.',
    description: 'En yüksek berraklıktaki damla ve yuvarlak kesim pırlantaların zarafetle işlendiği bu küpeler, her harekette ışığı mükemmel şekilde yansıtacak biçimde tasarlanmıştır. Maison d\'Élite atölyelerinde el işçiliği ile üretilmiştir.',
    specs: {
      'Metal': '18 Ayar Beyaz Altın',
      'Pırlanta Ağırlığı': '4.20 Karat Toplam',
      'Pırlanta Berraklığı': 'VVS1',
      'Pırlanta Rengi': 'D Color (Ekstra Beyaz)',
      'Kesim': 'Damla ve Yuvarlak Parlak Kesim',
      'Sertifika': 'GIA Sertifikalı'
    }
  },
  {
    id: 'diamond-ring',
    name: 'Elmas Soliter Alyans Yüzük',
    category: 'yuzuk',
    categoryName: 'Yüzük',
    price: 18500,
    priceStr: '18.500 $',
    imageKey: 'diamond_ring',
    badge: 'Klasik',
    shortDesc: 'Büyüleyici 2 karatlık tektaş pırlanta pencereli zarif yüzük.',
    description: 'Sonsuz aşkın ve zarafetin simgesi olan bu yüzük, ortasında 6 tırnaklı platin yuvaya oturtulmuş 2 karatlık muhteşem bir tektaş pırlanta barındırır. Klasik tasarımı modern bir dokunuşla birleştiren özel bir parça.',
    specs: {
      'Metal': 'Platin 950',
      'Pırlanta Ağırlığı': '2.01 Karat Merkez',
      'Pırlanta Berraklığı': 'VS1',
      'Pırlanta Rengi': 'F Color',
      'Kesim': 'Yuvarlak Parlak Kesim (Excellent)',
      'Sertifika': 'GIA Sertifikalı'
    }
  }
];

// --- Absolute and Relative Paths for fallback mechanism ---
const ARTIFACT_DIR = 'file:///Users/egekolatan/.gemini/antigravity-ide/brain/76d36a1d-5a39-479a-8395-a815b05e2b27';
const IMAGE_PATHS = {
  hero: 'assets/luxury_hero.png',
  rolex_daytona: 'assets/rolex_daytona.png',
  patek_nautilus: 'assets/patek_nautilus.png',
  diamond_earrings: 'assets/diamond_earrings.png',
  diamond_ring: 'assets/diamond_ring.png',
  about_showroom: 'assets/about_showroom.png'
};

const IMAGE_FALLBACKS = {
  hero: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=1600&q=80',
  rolex_daytona: 'https://upload.wikimedia.org/wikipedia/commons/b/bc/Rolex_Daytona_Cosmograph.jpg',
  patek_nautilus: 'https://upload.wikimedia.org/wikipedia/commons/4/4c/Patek-Philippe-Nautilus-5711.jpg',
  diamond_earrings: 'https://upload.wikimedia.org/wikipedia/commons/e/ea/Marie_antoinette_diamond_earrings.jpg',
  diamond_ring: 'https://upload.wikimedia.org/wikipedia/commons/4/43/Diamond_ring_by_stephend9.jpg',
  about_showroom: 'https://upload.wikimedia.org/wikipedia/commons/2/2f/Boutique_Patek_Philippe_Paris.JPG'
};

// Global state variables
let cart = [];
let activeCategory = 'all';
let searchQuery = '';

// --- LocalStorage Logic ---
function saveCartToStorage() {
  localStorage.setItem('maison_elite_cart', JSON.stringify(cart));
}

function loadCartFromStorage() {
  const stored = localStorage.getItem('maison_elite_cart');
  if (stored) {
    try {
      cart = JSON.parse(stored);
    } catch (e) {
      cart = [];
    }
  }
}

// --- Image Fallback Utility for dynamic tags ---
window.handleImageError = function(imgElement, key) {
  if (IMAGE_FALLBACKS[key]) {
    imgElement.src = IMAGE_FALLBACKS[key];
    imgElement.onerror = null; // Prevent infinite loops
  }
};

// --- Render Products ---
function renderProducts() {
  const grid = document.getElementById('product-grid');
  if (!grid) return;

  grid.innerHTML = '';

  const filtered = PRODUCTS.filter(product => {
    const matchesCategory = activeCategory === 'all' || product.category === activeCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.categoryName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.shortDesc.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; color: var(--color-text-muted); padding: 4rem 0; font-weight: 300;">
        Aramanızla eşleşen lüks bir parça bulunamadı.
      </div>
    `;
    return;
  }

  filtered.forEach(product => {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    card.innerHTML = `
      <div class="product-image-wrapper">
        ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
        <img src="${IMAGE_PATHS[product.imageKey]}" alt="${product.name}" onerror="handleImageError(this, '${product.imageKey}')">
        <div class="product-overlay-actions">
          <button class="overlay-btn" onclick="openDetailModal('${product.id}')">Detayları Gör</button>
          <button class="overlay-btn" onclick="addToCart('${product.id}')">Sepete Ekle</button>
        </div>
      </div>
      <div class="product-info">
        <span class="product-category">${product.categoryName}</span>
        <h3 class="product-title">${product.name}</h3>
        <span class="product-price">${product.priceStr}</span>
      </div>
    `;
    grid.appendChild(card);
  });
}

// --- Cart Actions ---
window.addToCart = function(productId) {
  const product = PRODUCTS.find(p => p.id === productId);
  if (!product) return;

  const existing = cart.find(item => item.id === productId);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      priceStr: product.priceStr,
      imageKey: product.imageKey,
      quantity: 1
    });
  }

  saveCartToStorage();
  updateCartUI();
  showToast('Sepete Ekleme Başarılı', `${product.name} alışveriş sepetinize eklendi.`);
};

window.removeFromCart = function(productId) {
  cart = cart.filter(item => item.id !== productId);
  saveCartToStorage();
  updateCartUI();
};

window.changeQuantity = function(productId, delta) {
  const item = cart.find(item => item.id === productId);
  if (!item) return;

  item.quantity += delta;
  if (item.quantity <= 0) {
    removeFromCart(productId);
  } else {
    saveCartToStorage();
    updateCartUI();
  }
};

window.clearCart = function() {
  cart = [];
  saveCartToStorage();
  updateCartUI();
};

window.checkout = function() {
  if (cart.length === 0) return;
  
  // Show a premium confirmation alert
  alert('Tebrikler! Lüks siparişiniz başarıyla alındı. Müşteri temsilcimiz sizinle en kısa sürede iletişime geçecektir.');
  clearCart();
  toggleCart(false);
};

// --- Cart UI Updates ---
function updateCartUI() {
  const countBadge = document.getElementById('cart-count');
  const wrapper = document.getElementById('cart-items-wrapper');
  const totalVal = document.getElementById('cart-total-val');

  // Update navbar badge
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  if (countBadge) {
    countBadge.textContent = totalItems;
    countBadge.style.display = totalItems > 0 ? 'flex' : 'none';
  }

  // Update sidebar list
  if (wrapper) {
    wrapper.innerHTML = '';
    if (cart.length === 0) {
      wrapper.innerHTML = `<div class="cart-empty-message">Alışveriş sepetiniz şu anda boş.</div>`;
    } else {
      cart.forEach(item => {
        const itemEl = document.createElement('div');
        itemEl.className = 'cart-item';
        itemEl.innerHTML = `
          <img class="cart-item-img" src="${IMAGE_PATHS[item.imageKey]}" alt="${item.name}" onerror="handleImageError(this, '${item.imageKey}')">
          <div class="cart-item-info">
            <h4 class="cart-item-title">${item.name}</h4>
            <span class="cart-item-price">${item.priceStr}</span>
            <div class="cart-item-controls">
              <div class="qty-controls">
                <button class="qty-btn" onclick="changeQuantity('${item.id}', -1)">-</button>
                <span class="qty-val">${item.quantity}</span>
                <button class="qty-btn" onclick="changeQuantity('${item.id}', 1)">+</button>
              </div>
              <button class="cart-item-remove" onclick="removeFromCart('${item.id}')">Kaldır</button>
            </div>
          </div>
        `;
        wrapper.appendChild(itemEl);
      });
    }
  }

  // Update total sum
  if (totalVal) {
    const totalSum = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    totalVal.textContent = totalSum === 0 ? '0 $' : `${totalSum.toLocaleString('tr-TR')} $`;
  }
}

// --- Cart Sidebar Open/Close ---
window.toggleCart = function(isOpen) {
  const sidebar = document.getElementById('cart-sidebar');
  const backdrop = document.getElementById('overlay-backdrop');
  if (sidebar && backdrop) {
    if (isOpen) {
      sidebar.classList.add('open');
      backdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    } else {
      sidebar.classList.remove('open');
      // Only remove backdrop active if detail modal is also closed
      const detailModal = document.getElementById('detail-modal');
      if (!detailModal || !detailModal.classList.contains('open')) {
        backdrop.classList.remove('active');
        document.body.style.overflow = 'auto';
      }
    }
  }
};

// --- Product Detail Modal ---
window.openDetailModal = function(productId) {
  const product = PRODUCTS.find(p => p.id === productId);
  if (!product) return;

  const modal = document.getElementById('detail-modal');
  const backdrop = document.getElementById('overlay-backdrop');
  if (!modal || !backdrop) return;

  // Set modal elements
  document.getElementById('modal-img').src = IMAGE_PATHS[product.imageKey];
  document.getElementById('modal-img').onerror = function() {
    handleImageError(this, product.imageKey);
  };
  document.getElementById('modal-category').textContent = product.categoryName;
  document.getElementById('modal-title').textContent = product.name;
  document.getElementById('modal-price').textContent = product.priceStr;
  document.getElementById('modal-description').textContent = product.description;

  // Build specs list
  const specsContainer = document.getElementById('modal-specs');
  specsContainer.innerHTML = '';
  for (const [key, value] of Object.entries(product.specs)) {
    const specRow = document.createElement('div');
    specRow.className = 'spec-item';
    specRow.innerHTML = `
      <span class="spec-label">${key}</span>
      <span class="spec-value">${value}</span>
    `;
    specsContainer.appendChild(specRow);
  }

  // Set checkout action button
  const actionContainer = document.getElementById('modal-action');
  actionContainer.innerHTML = `
    <button class="gold-btn" style="width: 100%;" onclick="addToCart('${product.id}'); closeDetailModal();">Sepete Ekle</button>
  `;

  // Open modal
  modal.classList.add('open');
  backdrop.classList.add('active');
  document.body.style.overflow = 'hidden';
};

window.closeDetailModal = function() {
  const modal = document.getElementById('detail-modal');
  const backdrop = document.getElementById('overlay-backdrop');
  if (modal) {
    modal.classList.remove('open');
    // Only remove backdrop if cart sidebar is also closed
    const sidebar = document.getElementById('cart-sidebar');
    if (!sidebar || !sidebar.classList.contains('open')) {
      backdrop.classList.remove('active');
      document.body.style.overflow = 'auto';
    }
  }
};

// --- Premium Toast Utility ---
function showToast(title, message) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <div class="toast-icon">✨</div>
    <div class="toast-content">
      <h5>${title}</h5>
      <p>${message}</p>
    </div>
  `;

  container.appendChild(toast);

  // Auto remove toast
  setTimeout(() => {
    toast.classList.add('removing');
    toast.addEventListener('animationend', () => {
      toast.remove();
    });
  }, 4000);
}

// --- Category Filtering Event Listeners ---
function initFilters() {
  const buttons = document.querySelectorAll('.filter-btn');
  buttons.forEach(button => {
    button.addEventListener('click', () => {
      buttons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      activeCategory = button.getAttribute('data-category');
      renderProducts();
    });
  });
}

// --- Search Bar Input Event Listener ---
function initSearch() {
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value;
      renderProducts();
    });
  }
}

// --- Window Scroll Event (Sticky Navbar styling) ---
function initScroll() {
  const header = document.querySelector('header');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });
}

// --- Handle Showroom Image Fallback (static image on load) ---
function initShowroomFallback() {
  const showroomImg = document.getElementById('showroom-image');
  if (showroomImg) {
    showroomImg.src = IMAGE_PATHS.about_showroom;
    showroomImg.onerror = function() {
      handleImageError(this, 'about_showroom');
    };
  }

  const heroSection = document.getElementById('hero-section');
  if (heroSection) {
    // Dynamically test hero image and apply as inline background
    const tempImg = new Image();
    tempImg.src = IMAGE_PATHS.hero;
    tempImg.onload = function() {
      heroSection.style.backgroundImage = `url('${IMAGE_PATHS.hero}')`;
    };
    tempImg.onerror = function() {
      heroSection.style.backgroundImage = `url('${IMAGE_FALLBACKS.hero}')`;
    };
  }
}

// --- Contact Form Submission ---
function initContactForm() {
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('form-name').value;
      showToast('Mesajınız Gönderildi', `Değerli ${name}, vip talebiniz alındı. Danışmanlarımız sizinle iletişime geçecektir.`);
      form.reset();
    });
  }
}

// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
  loadCartFromStorage();
  updateCartUI();
  initFilters();
  initSearch();
  initScroll();
  initShowroomFallback();
  initContactForm();
  renderProducts();

  // Backdrop click closes everything
  const backdrop = document.getElementById('overlay-backdrop');
  if (backdrop) {
    backdrop.addEventListener('click', () => {
      toggleCart(false);
      closeDetailModal();
    });
  }
});
